import React from 'react'
import {Button,Text,View, TouchableOpacity,StyleSheet} from 'react-native';


RenderAnswers = (props)=>{
    console.log(typeof props.answerOne.answer)  

        
        

    return(
        <View>
            {/* <View style={{flexDirection:'row'}}>
                <TouchableOpacity
                style={styles.appButtonKid}
                onPress={()=> props.next(props.answers.answerOne)}>
                    <Text style={styles.appButtonText}>{props.answerOne}</Text>
                </TouchableOpacity>
                <TouchableOpacity
                style={styles.appButtonKid}
                onPress={()=> props.next(props.answers.answerTwo)}>
                    <Text style={styles.appButtonText}>{props.answerTwo}</Text>
                </TouchableOpacity>
            </View>
            <View style={{flexDirection:'row'}}>
                <TouchableOpacity
                style={styles.appButtonKid}
                onPress={()=> props.next(props.answers.answerThree)}>
                    <Text style={styles.appButtonText}>{props.answerThree}</Text>
                </TouchableOpacity>
                <TouchableOpacity
                style={styles.appButtonKid}
                onPress={()=> props.next(props.answers.answerFour)}>
                    <Text style={styles.appButtonText}>{props.answerFour}</Text>
                </TouchableOpacity>
            </View> */}
        </View>
    )
        
}

const AnswerComponent = (props) => {
    return (
    <View>
        <TouchableOpacity style={{justifyContent: 'center',
            alignItems: 'center',marginTop:300}}>
              {RenderAnswers(props.answers)}
        </TouchableOpacity>
    </View>
    )
}

const styles = StyleSheet.create({
    // ...
    appButtonContainer: {
    margin:30,
      backgroundColor: "#FFADAD",
      borderRadius: 50,
      borderWidth:3,
      borderColor:'#FDFFB6',
      paddingVertical: 20,
      paddingHorizontal: 50
    },
    appButtonKid: {
        margin:10,
        backgroundColor: "#CAFFBF",
        borderRadius: 50,
        borderWidth:3,
        borderColor:'#FDFFB6',
        paddingVertical: 5,
        paddingHorizontal: 20,
        width:150,
        justifyContent: 'center',
        alignItems: 'center'
        },
    appButtonText: {
      fontSize: 24,
      color: "#FFADAD",
      fontWeight: "bold",
      alignSelf: "center",
      textTransform: "uppercase"
    }
  });
export default AnswerComponent;
