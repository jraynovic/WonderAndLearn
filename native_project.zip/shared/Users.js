export const USERS = [
    {
        id:0,
        name:'Henry',
        avatar:require('C:/Users/Lenovo/Desktop/ReactNative_Project/nativeProject/components/images/creeper.jpg'),
        challenge:[{name:'Math',location:'Math'},{name:'History',location:'History'}]
    },
    {
        id:1,
        name:'Katherine',
        avatar:require('C:/Users/Lenovo/Desktop/ReactNative_Project/nativeProject/components/images/barbie.jpg'),
        challenge:[{name:'Math',location:'Math'},]
        
    },
    
]

// avatar:"require('./images/barbie.jpg')"