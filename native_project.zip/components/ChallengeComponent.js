import React, { Component } from 'react'
import {Button,Text,View, TouchableOpacity,StyleSheet} from 'react-native';
import ScoreComponent from './kid/ScoreComponent';
import QuestionComponent from './kid/QuestionComponent';
import QUESTIONS from '../shared/questions'
import AnswerComponent from './kid/AnswerComponent';

class ChallengeComponent extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            score:0,
            questions:0,
            currentQuestion:0,
            questionsList:'nothing'
         }
    }
    componentDidMount() {
        // alert(this.props.navigation.getParam('selected'))
        // alert(JSON.stringify(QUESTIONS[1].name))
        const questionToAsk  = QUESTIONS.filter(question => question.name === this.props.navigation.getParam('selected'))[0]
        // alert(questionToAsk.name)

        this.setState({
            questionsList:questionToAsk.questions,
            questions: questionToAsk.length
        })
     
        
    }
    NextQuestion = (answer)=>{
        if (this.state.currentQuestion-1<this.state.questions){
            this.setState({
                currentQuestion: this.state.currentQuestion+1
            })
            if(answer.correct){
                this.setState(
                    { score: this.state.score+5 }
                )
            }
        }
    }

    render() {
        const { navigate } = this.props.navigation;
        
        

        


        return (
            <View style={{flex:1,
                backgroundColor:this.state.questionsList[this.state.currentQuestion].background,
            }}>
                <View style={{flexDirection:'row',justifyContent:'flex-end',marginTop:-20,marginRight:-20}}>
                    <ScoreComponent score={this.state.score}/>
                </View>
                <View style={{justifyContent:'center',alignItems:'center'}}>
                    <QuestionComponent question={this.state.questionsList[this.state.currentQuestion].question} next={this.NextQuestion}/> 
                </View>
                <View>
                    <AnswerComponent answers = {this.state.questionsList[this.state.currentQuestion]} next={this.NextQuestion}/>
                </View>
            </View>
        )
    }
}
const styles = StyleSheet.create({
    // ...
    appButtonContainer: {
    margin:30,
      backgroundColor: "#FFADAD",
      borderRadius: 50,
      borderWidth:3,
      borderColor:'#FDFFB6',
      paddingVertical: 20,
      paddingHorizontal: 50
    },
    appButtonKid: {
        margin:30,
        backgroundColor: "#FFD6A5",
        borderRadius: 50,
        borderWidth:3,
        borderColor:'#FDFFB6',
        paddingVertical: 20,
        paddingHorizontal: 50
        },
    appButtonText: {
      fontSize: 18,
      color: "#fff",
      fontWeight: "bold",
      alignSelf: "center",
      textTransform: "uppercase"
    }
  });
export default ChallengeComponent;