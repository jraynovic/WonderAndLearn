import React, { Component } from 'react';
import {Text,View} from 'react-native';
import {createStackNavigator} from 'react-navigation';
import HomeComponent from './HomeComponent';
import ParentComponent from './ParentComponent';
import KidComponent from './KidComponent'
import TemplateComponent from './TemplateComponent'
import ChallengeComponent from './ChallengeComponent';
import ChooseUser from './ChooseUser'
import ChallengeList from './ChallengeList';
// import PreviewComponent from './PreviewComponent'

// const RenderHome = () =>{
//     return(
//         <HomeComponent/>    
//     )
// }

const HomeNavigator = createStackNavigator(
    {
        Home:{
            screen: HomeComponent,
        },
        Parent:{screen:ParentComponent},
        Kid:{screen:KidComponent},
        Templates:{screen:TemplateComponent},
        Challenge:{screen:ChallengeComponent},
        ChooseUser:{screen:ChooseUser},
        ChallengeList:{screen:ChallengeList}
        // Preview: { screen:PreviewComponent }
    },
    {
        initialRouteName: 'Home',
        headerMode: 'none',
      }
)

export default class MainComponent extends Component {
    render() {
        return (
           
               <HomeNavigator/>
        )
    }
}
